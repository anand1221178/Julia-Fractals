echo ------------Fractal is starting---------------
./fractal |& tee -a terminal.out
echo -------------Fractal is done------------------
echo
